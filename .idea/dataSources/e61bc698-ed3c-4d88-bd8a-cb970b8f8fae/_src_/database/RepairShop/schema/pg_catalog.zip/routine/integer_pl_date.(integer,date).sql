create function pg_catalog.integer_pl_date(integer, date) returns date
LANGUAGE SQL
AS $$
select $2 + $1
$$;
