create function pg_catalog.bit_length(bit) returns integer
LANGUAGE SQL
AS $$
select pg_catalog.length($1)
$$;
